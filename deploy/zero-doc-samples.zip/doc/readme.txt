Zero
====

Zero is a pure object-oriented, prototype-based, persistent programming system.
It's main objective is to serve as an easy path for learning object-oriented programming.

Installation
============

Unpack the contents in any directory. Open a console in that directory in order to work with zero (this is in case you are going to use the command-line tools, which is highly probable).

Execute zero programs
=====================

You have to compile and then execute them. For example, in order to execute
the "HolaMundo" object (the spanish version of the "Hello, World!" object), type:

c:\zero> zm HolaMundo.zm
c:\zero> zvm HolaMundo

NOTE: zvm looks for a file with the name provided plus the extension ".zbj". If found, then
it searchs inside it for the "main" object which must be called with the same name as
the file. If the object derives from the ConsoleApplication object, then it is not
necessary to specify anything else. In other cases, you will have also to provide the method
to be called. For example, "SomeObject" has a main() method which must be the one 
to be triggered:

$ zm SomeObject.zm
$ zvm SomeObject main

License
=======

Please refer to file "zlicencia.html"


-----
jbgarcia@uvigo.es

