# Por Ignacio Casal Quinteiro
# icq@gnome.org
# Instala el resaltado de sintaxis para PROWL en gEdit y Anjuta
mkdir -p ~/.local/share/gtksourceview-2.0/language-specs
cp prowl.lang ~/.local/share/gtksourceview-2.0/language-specs
